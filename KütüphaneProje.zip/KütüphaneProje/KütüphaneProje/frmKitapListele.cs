﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KütüphaneProje
{
    public partial class frmKitapListele : Form
    {
        public frmKitapListele()
        {
            InitializeComponent();
        }

        private void frmKitapListele_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'proje_DBDataSet.TBLKitaplar' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.tBLKitaplarTableAdapter.Fill(this.proje_DBDataSet.TBLKitaplar);
            // TODO: Bu kod satırı 'proje_DBDataSet.TBLKitapTürü' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.tBLKitapTürüTableAdapter.Fill(this.proje_DBDataSet.TBLKitapTürü);
            // TODO: Bu kod satırı 'proje_DBDataSet.View_Kitap' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.view_KitapTableAdapter.Fill(this.proje_DBDataSet.View_Kitap);

        }
        Proje_DBDataSetTableAdapters.TBLKitaplarTableAdapter db = new Proje_DBDataSetTableAdapters.TBLKitaplarTableAdapter();

        private void btnSil_Click(object sender, EventArgs e)
        {
            int kitapID = Convert.ToInt32(kitapIDTextBox.Text);
            db.KitapSil(kitapID);
            this.tBLKitaplarTableAdapter.Fill(this.proje_DBDataSet.TBLKitaplar);
            this.tBLKitapTürüTableAdapter.Fill(this.proje_DBDataSet.TBLKitapTürü);
            this.view_KitapTableAdapter.Fill(this.proje_DBDataSet.View_Kitap);
            MessageBox.Show("Silme  İşlemi Başarılı", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);


        }

        private void btnGüncelle_Click(object sender, EventArgs e)
        {


            int kitapID = Convert.ToInt32(kitapIDTextBox.Text); // ya da int.TryParse ile güvenli kontrol
            int kitapTuruID = Convert.ToInt32(kitapTürAdiComboBox.SelectedValue);
            int stok = Convert.ToInt32(stokSayisiTextBox.Text);
            int sayfa = Convert.ToInt32(sayfaSayisiTextBox.Text);
            DateTime tarih = kayitTarihiDateTimePicker.Value;

            db.KitapGüncelle(
                kitapID,
                kitapTuruID,
                barkodNoTextBox.Text,
                kitapAdiTextBox.Text,
                yazariTextBox.Text,
                yayıneviTextBox.Text,
                sayfa.ToString(),           // Metot string olarak bekliyorsa
                rafNoTextBox.Text,
                açiklamaTextBox.Text,
                tarih.ToString("yyyy-MM-dd"),
                stok
            );


            this.tBLKitaplarTableAdapter.Fill(this.proje_DBDataSet.TBLKitaplar);
            this.tBLKitapTürüTableAdapter.Fill(this.proje_DBDataSet.TBLKitapTürü);
            this.view_KitapTableAdapter.Fill(this.proje_DBDataSet.View_Kitap);
            MessageBox.Show("Güncelleme  İşlemi Başarılı", "Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {
            view_KitapBindingSource.Filter = "KitapAdi like '% " + toolStripTextBox1.Text + "%'";
        }
    }
}
