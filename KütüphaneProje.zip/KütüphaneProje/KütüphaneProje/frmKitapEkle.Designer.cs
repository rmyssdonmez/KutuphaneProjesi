﻿namespace KütüphaneProje
{
    partial class frmKitapEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label kitapTürüIDLabel;
            this.label1 = new System.Windows.Forms.Label();
            this.cmbKitapTürü = new System.Windows.Forms.ComboBox();
            this.tBLKitapTürüBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.proje_DBDataSet = new KütüphaneProje.Proje_DBDataSet();
            this.txtStokSayisi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBarkodNo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtKitapAdi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtYazar = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtYayınevi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtRafNo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSayfaSayisi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAçıklama = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnEkle = new System.Windows.Forms.Button();
            this.tBLKitaplarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tBLKitaplarTableAdapter = new KütüphaneProje.Proje_DBDataSetTableAdapters.TBLKitaplarTableAdapter();
            this.tableAdapterManager = new KütüphaneProje.Proje_DBDataSetTableAdapters.TableAdapterManager();
            this.tBLKitapTürüTableAdapter = new KütüphaneProje.Proje_DBDataSetTableAdapters.TBLKitapTürüTableAdapter();
            this.tBLSepetTableAdapter = new KütüphaneProje.Proje_DBDataSetTableAdapters.TBLSepetTableAdapter();
            this.kitapIDComboBox = new System.Windows.Forms.ComboBox();
            this.fKTBLSepetTBLKitaplarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnKapat = new System.Windows.Forms.Button();
            kitapTürüIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tBLKitapTürüBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proje_DBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLKitaplarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLSepetTBLKitaplarBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // kitapTürüIDLabel
            // 
            kitapTürüIDLabel.AutoSize = true;
            kitapTürüIDLabel.Location = new System.Drawing.Point(30, 15);
            kitapTürüIDLabel.Name = "kitapTürüIDLabel";
            kitapTürüIDLabel.Size = new System.Drawing.Size(56, 16);
            kitapTürüIDLabel.TabIndex = 23;
            kitapTürüIDLabel.Text = "Kitap ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kitap Türü ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // cmbKitapTürü
            // 
            this.cmbKitapTürü.DataSource = this.tBLKitapTürüBindingSource;
            this.cmbKitapTürü.DisplayMember = "KitapTürAdi";
            this.cmbKitapTürü.FormattingEnabled = true;
            this.cmbKitapTürü.Location = new System.Drawing.Point(151, 47);
            this.cmbKitapTürü.Name = "cmbKitapTürü";
            this.cmbKitapTürü.Size = new System.Drawing.Size(200, 24);
            this.cmbKitapTürü.TabIndex = 1;
            this.cmbKitapTürü.ValueMember = "KitapTürüID";
            this.cmbKitapTürü.SelectedIndexChanged += new System.EventHandler(this.cmbKitapTürID_SelectedIndexChanged);
            // 
            // tBLKitapTürüBindingSource
            // 
            this.tBLKitapTürüBindingSource.DataMember = "TBLKitapTürü";
            this.tBLKitapTürüBindingSource.DataSource = this.proje_DBDataSet;
            // 
            // proje_DBDataSet
            // 
            this.proje_DBDataSet.DataSetName = "Proje_DBDataSet";
            this.proje_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtStokSayisi
            // 
            this.txtStokSayisi.Location = new System.Drawing.Point(151, 88);
            this.txtStokSayisi.Name = "txtStokSayisi";
            this.txtStokSayisi.Size = new System.Drawing.Size(200, 22);
            this.txtStokSayisi.TabIndex = 5;
            this.txtStokSayisi.TextChanged += new System.EventHandler(this.txtStokSayisi_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Stok Sayısı";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtBarkodNo
            // 
            this.txtBarkodNo.Location = new System.Drawing.Point(151, 134);
            this.txtBarkodNo.Name = "txtBarkodNo";
            this.txtBarkodNo.Size = new System.Drawing.Size(200, 22);
            this.txtBarkodNo.TabIndex = 7;
            this.txtBarkodNo.TextChanged += new System.EventHandler(this.txtBarkodNo_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Barkod Numarası";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtKitapAdi
            // 
            this.txtKitapAdi.Location = new System.Drawing.Point(151, 185);
            this.txtKitapAdi.Name = "txtKitapAdi";
            this.txtKitapAdi.Size = new System.Drawing.Size(200, 22);
            this.txtKitapAdi.TabIndex = 9;
            this.txtKitapAdi.TextChanged += new System.EventHandler(this.txtKitapAdi_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Kitap Adı";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtYazar
            // 
            this.txtYazar.Location = new System.Drawing.Point(151, 230);
            this.txtYazar.Name = "txtYazar";
            this.txtYazar.Size = new System.Drawing.Size(200, 22);
            this.txtYazar.TabIndex = 11;
            this.txtYazar.TextChanged += new System.EventHandler(this.txtYazar_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 236);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Yazar";
            // 
            // txtYayınevi
            // 
            this.txtYayınevi.Location = new System.Drawing.Point(151, 283);
            this.txtYayınevi.Name = "txtYayınevi";
            this.txtYayınevi.Size = new System.Drawing.Size(200, 22);
            this.txtYayınevi.TabIndex = 13;
            this.txtYayınevi.TextChanged += new System.EventHandler(this.txtYayınevi_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "Yayınevi";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtRafNo
            // 
            this.txtRafNo.Location = new System.Drawing.Point(151, 374);
            this.txtRafNo.Name = "txtRafNo";
            this.txtRafNo.Size = new System.Drawing.Size(200, 22);
            this.txtRafNo.TabIndex = 17;
            this.txtRafNo.TextChanged += new System.EventHandler(this.txtRafNo_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(31, 380);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 16);
            this.label8.TabIndex = 16;
            this.label8.Text = "Raf Numarası";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txtSayfaSayisi
            // 
            this.txtSayfaSayisi.Location = new System.Drawing.Point(151, 321);
            this.txtSayfaSayisi.Name = "txtSayfaSayisi";
            this.txtSayfaSayisi.Size = new System.Drawing.Size(200, 22);
            this.txtSayfaSayisi.TabIndex = 15;
            this.txtSayfaSayisi.TextChanged += new System.EventHandler(this.txtSayfaSayisi_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(31, 327);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 16);
            this.label9.TabIndex = 14;
            this.label9.Text = "Sayfa Sayısı";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtAçıklama
            // 
            this.txtAçıklama.Location = new System.Drawing.Point(151, 421);
            this.txtAçıklama.Name = "txtAçıklama";
            this.txtAçıklama.Size = new System.Drawing.Size(200, 22);
            this.txtAçıklama.TabIndex = 19;
            this.txtAçıklama.TextChanged += new System.EventHandler(this.txtAçıklama_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 427);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 16);
            this.label10.TabIndex = 18;
            this.label10.Text = "Açıklama";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(31, 466);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 16);
            this.label11.TabIndex = 20;
            this.label11.Text = "Tarih";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(151, 461);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 21;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // btnEkle
            // 
            this.btnEkle.BackColor = System.Drawing.Color.Lime;
            this.btnEkle.Location = new System.Drawing.Point(478, 421);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(111, 54);
            this.btnEkle.TabIndex = 22;
            this.btnEkle.Text = "Ekle";
            this.btnEkle.UseVisualStyleBackColor = false;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // tBLKitaplarBindingSource
            // 
            this.tBLKitaplarBindingSource.DataMember = "TBLKitaplar";
            this.tBLKitaplarBindingSource.DataSource = this.proje_DBDataSet;
            // 
            // tBLKitaplarTableAdapter
            // 
            this.tBLKitaplarTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TBLEmanetKitaplarTableAdapter = null;
            this.tableAdapterManager.TBLİadeKitaplarTableAdapter = null;
            this.tableAdapterManager.TBLKitaplarTableAdapter = this.tBLKitaplarTableAdapter;
            this.tableAdapterManager.TBLKitapTürüTableAdapter = this.tBLKitapTürüTableAdapter;
            this.tableAdapterManager.TBLSepetTableAdapter = this.tBLSepetTableAdapter;
            this.tableAdapterManager.TBLUyelerTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = KütüphaneProje.Proje_DBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tBLKitapTürüTableAdapter
            // 
            this.tBLKitapTürüTableAdapter.ClearBeforeFill = true;
            // 
            // tBLSepetTableAdapter
            // 
            this.tBLSepetTableAdapter.ClearBeforeFill = true;
            // 
            // kitapIDComboBox
            // 
            this.kitapIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tBLKitaplarBindingSource, "KitapTürüID", true));
            this.kitapIDComboBox.FormattingEnabled = true;
            this.kitapIDComboBox.Location = new System.Drawing.Point(151, 12);
            this.kitapIDComboBox.Name = "kitapIDComboBox";
            this.kitapIDComboBox.Size = new System.Drawing.Size(200, 24);
            this.kitapIDComboBox.TabIndex = 24;
            // 
            // fKTBLSepetTBLKitaplarBindingSource
            // 
            this.fKTBLSepetTBLKitaplarBindingSource.DataMember = "FK_TBLSepet_TBLKitaplar";
            this.fKTBLSepetTBLKitaplarBindingSource.DataSource = this.tBLKitaplarBindingSource;
            // 
            // btnKapat
            // 
            this.btnKapat.BackColor = System.Drawing.Color.Red;
            this.btnKapat.Location = new System.Drawing.Point(646, 421);
            this.btnKapat.Name = "btnKapat";
            this.btnKapat.Size = new System.Drawing.Size(111, 54);
            this.btnKapat.TabIndex = 25;
            this.btnKapat.Text = "Kapat";
            this.btnKapat.UseVisualStyleBackColor = false;
            this.btnKapat.Click += new System.EventHandler(this.btnKapat_Click);
            // 
            // frmKitapEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 545);
            this.Controls.Add(this.btnKapat);
            this.Controls.Add(kitapTürüIDLabel);
            this.Controls.Add(this.kitapIDComboBox);
            this.Controls.Add(this.btnEkle);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtAçıklama);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtRafNo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtSayfaSayisi);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtYayınevi);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtYazar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtKitapAdi);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtBarkodNo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtStokSayisi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbKitapTürü);
            this.Controls.Add(this.label1);
            this.Name = "frmKitapEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kitap Ekle";
            this.Load += new System.EventHandler(this.frmKitapEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tBLKitapTürüBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proje_DBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLKitaplarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLSepetTBLKitaplarBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbKitapTürü;
        private System.Windows.Forms.TextBox txtStokSayisi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBarkodNo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtKitapAdi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtYazar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtYayınevi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtRafNo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSayfaSayisi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAçıklama;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnEkle;
        private Proje_DBDataSet proje_DBDataSet;
        private System.Windows.Forms.BindingSource tBLKitaplarBindingSource;
        private Proje_DBDataSetTableAdapters.TBLKitaplarTableAdapter tBLKitaplarTableAdapter;
        private Proje_DBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox kitapIDComboBox;
        private Proje_DBDataSetTableAdapters.TBLSepetTableAdapter tBLSepetTableAdapter;
        private System.Windows.Forms.BindingSource fKTBLSepetTBLKitaplarBindingSource;
        private Proje_DBDataSetTableAdapters.TBLKitapTürüTableAdapter tBLKitapTürüTableAdapter;
        private System.Windows.Forms.BindingSource tBLKitapTürüBindingSource;
        private System.Windows.Forms.Button btnKapat;
    }
}