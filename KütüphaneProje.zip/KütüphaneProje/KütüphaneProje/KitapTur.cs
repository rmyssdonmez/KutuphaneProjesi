﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace KütüphaneProje
{
    public partial class KitapTur : Form
    {
        public KitapTur()
        {
            InitializeComponent();
        }

        private void tBLKitapTürüBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tBLKitapTürüBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.proje_DBDataSet);

        }

        private void KitapTur_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'proje_DBDataSet.TBLKitapTürü' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.tBLKitapTürüTableAdapter.Fill(this.proje_DBDataSet.TBLKitapTürü);
            listView1.View = View.Details;
            listView1.Columns.Add("Kitap Türü ID", 100);
            listView1.Columns.Add("Kitap Türü Adı", 200);

            foreach (var item in proje_DBDataSet.TBLKitapTürü)
            {
                ListViewItem ekle = new ListViewItem(item.KitapTürüID.ToString());
                ekle.SubItems.Add(item.KitapTürAdi);
                listView1.Items.Add(ekle);
            }

        }

        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {
            tBLKitapTürüBindingSource.Filter = "KitapTürAdi LIKE '%" + toolStripTextBox1.Text + "%'";

        }
        Proje_DBDataSetTableAdapters.TBLKitapTürüTableAdapter db = new Proje_DBDataSetTableAdapters.TBLKitapTürüTableAdapter();
        private void btnEkle_Click(object sender, EventArgs e)
        {

            

           
           

 
        }

    }
    }

