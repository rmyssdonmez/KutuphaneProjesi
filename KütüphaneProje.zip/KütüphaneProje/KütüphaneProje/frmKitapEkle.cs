﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KütüphaneProje
{
    public partial class frmKitapEkle : Form
    {
        public frmKitapEkle()
        {
            InitializeComponent();
        }

        private void frmKitapEkle_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'proje_DBDataSet.TBLKitapTürü' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.tBLKitapTürüTableAdapter.Fill(this.proje_DBDataSet.TBLKitapTürü);
            // TODO: Bu kod satırı 'proje_DBDataSet.TBLSepet' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.tBLSepetTableAdapter.Fill(this.proje_DBDataSet.TBLSepet);
            // TODO: Bu kod satırı 'proje_DBDataSet.TBLKitaplar' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.tBLKitaplarTableAdapter.Fill(this.proje_DBDataSet.TBLKitaplar);

        }

        private void txtAçıklama_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void txtRafNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void txtSayfaSayisi_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void txtYayınevi_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtYazar_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtKitapAdi_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtBarkodNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtStokSayisi_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cmbKitapTürID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tBLKitaplarBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tBLKitaplarBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.proje_DBDataSet);

        }
        Proje_DBDataSetTableAdapters.TBLKitaplarTableAdapter db = new Proje_DBDataSetTableAdapters.TBLKitaplarTableAdapter();
        private void btnEkle_Click(object sender, EventArgs e)
        {
            int kitapTuruID = Convert.ToInt32(cmbKitapTürü.SelectedValue);
            int stokSayisi = Convert.ToInt32(txtStokSayisi.Text);
            string sayfaSayisi = txtSayfaSayisi.Text;

            DateTime tarih = dateTimePicker1.Value; 

            db.Insert(
                kitapTuruID,                
                stokSayisi,                 
                txtBarkodNo.Text,           
                txtKitapAdi.Text,           
                txtYazar.Text,             
                txtYayınevi.Text,           
                 sayfaSayisi,               
                txtRafNo.Text,             
                txtAçıklama.Text,           
                tarih                      
            );
            this.tBLKitapTürüTableAdapter.Fill(this.proje_DBDataSet.TBLKitapTürü);
            this.tBLKitaplarTableAdapter.Fill(this.proje_DBDataSet.TBLKitaplar);
            MessageBox.Show("Kitap Ekleme İşlemi Başarılı", "Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnKapat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
