﻿namespace KütüphaneProje
{
    partial class frmKitapListele
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label kitapIDLabel;
            System.Windows.Forms.Label kitapTürAdiLabel;
            System.Windows.Forms.Label stokSayisiLabel;
            System.Windows.Forms.Label barkodNoLabel;
            System.Windows.Forms.Label kitapAdiLabel;
            System.Windows.Forms.Label yazariLabel;
            System.Windows.Forms.Label yayıneviLabel;
            System.Windows.Forms.Label sayfaSayisiLabel;
            System.Windows.Forms.Label rafNoLabel;
            System.Windows.Forms.Label açiklamaLabel;
            System.Windows.Forms.Label kayitTarihiLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKitapListele));
            this.proje_DBDataSet = new KütüphaneProje.Proje_DBDataSet();
            this.view_KitapBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_KitapTableAdapter = new KütüphaneProje.Proje_DBDataSetTableAdapters.View_KitapTableAdapter();
            this.tableAdapterManager = new KütüphaneProje.Proje_DBDataSetTableAdapters.TableAdapterManager();
            this.tBLKitaplarTableAdapter = new KütüphaneProje.Proje_DBDataSetTableAdapters.TBLKitaplarTableAdapter();
            this.tBLKitapTürüTableAdapter = new KütüphaneProje.Proje_DBDataSetTableAdapters.TBLKitapTürüTableAdapter();
            this.view_KitapBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnGüncelle = new System.Windows.Forms.ToolStripButton();
            this.btnSil = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.view_KitapDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kitapIDTextBox = new System.Windows.Forms.TextBox();
            this.kitapTürAdiComboBox = new System.Windows.Forms.ComboBox();
            this.tBLKitapTürüBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stokSayisiTextBox = new System.Windows.Forms.TextBox();
            this.barkodNoTextBox = new System.Windows.Forms.TextBox();
            this.kitapAdiTextBox = new System.Windows.Forms.TextBox();
            this.yazariTextBox = new System.Windows.Forms.TextBox();
            this.yayıneviTextBox = new System.Windows.Forms.TextBox();
            this.sayfaSayisiTextBox = new System.Windows.Forms.TextBox();
            this.rafNoTextBox = new System.Windows.Forms.TextBox();
            this.açiklamaTextBox = new System.Windows.Forms.TextBox();
            this.kayitTarihiDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.TBLKitaplarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            kitapIDLabel = new System.Windows.Forms.Label();
            kitapTürAdiLabel = new System.Windows.Forms.Label();
            stokSayisiLabel = new System.Windows.Forms.Label();
            barkodNoLabel = new System.Windows.Forms.Label();
            kitapAdiLabel = new System.Windows.Forms.Label();
            yazariLabel = new System.Windows.Forms.Label();
            yayıneviLabel = new System.Windows.Forms.Label();
            sayfaSayisiLabel = new System.Windows.Forms.Label();
            rafNoLabel = new System.Windows.Forms.Label();
            açiklamaLabel = new System.Windows.Forms.Label();
            kayitTarihiLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.proje_DBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_KitapBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_KitapBindingNavigator)).BeginInit();
            this.view_KitapBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.view_KitapDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLKitapTürüBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TBLKitaplarBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // kitapIDLabel
            // 
            kitapIDLabel.AutoSize = true;
            kitapIDLabel.Location = new System.Drawing.Point(29, 49);
            kitapIDLabel.Name = "kitapIDLabel";
            kitapIDLabel.Size = new System.Drawing.Size(56, 16);
            kitapIDLabel.TabIndex = 2;
            kitapIDLabel.Text = "Kitap ID:";
            // 
            // kitapTürAdiLabel
            // 
            kitapTürAdiLabel.AutoSize = true;
            kitapTürAdiLabel.Location = new System.Drawing.Point(29, 77);
            kitapTürAdiLabel.Name = "kitapTürAdiLabel";
            kitapTürAdiLabel.Size = new System.Drawing.Size(86, 16);
            kitapTürAdiLabel.TabIndex = 4;
            kitapTürAdiLabel.Text = "Kitap Tür Adi:";
            // 
            // stokSayisiLabel
            // 
            stokSayisiLabel.AutoSize = true;
            stokSayisiLabel.Location = new System.Drawing.Point(29, 107);
            stokSayisiLabel.Name = "stokSayisiLabel";
            stokSayisiLabel.Size = new System.Drawing.Size(77, 16);
            stokSayisiLabel.TabIndex = 6;
            stokSayisiLabel.Text = "Stok Sayisi:";
            // 
            // barkodNoLabel
            // 
            barkodNoLabel.AutoSize = true;
            barkodNoLabel.Location = new System.Drawing.Point(425, 46);
            barkodNoLabel.Name = "barkodNoLabel";
            barkodNoLabel.Size = new System.Drawing.Size(75, 16);
            barkodNoLabel.TabIndex = 8;
            barkodNoLabel.Text = "Barkod No:";
            // 
            // kitapAdiLabel
            // 
            kitapAdiLabel.AutoSize = true;
            kitapAdiLabel.Location = new System.Drawing.Point(425, 74);
            kitapAdiLabel.Name = "kitapAdiLabel";
            kitapAdiLabel.Size = new System.Drawing.Size(63, 16);
            kitapAdiLabel.TabIndex = 10;
            kitapAdiLabel.Text = "Kitap Adi:";
            // 
            // yazariLabel
            // 
            yazariLabel.AutoSize = true;
            yazariLabel.Location = new System.Drawing.Point(425, 102);
            yazariLabel.Name = "yazariLabel";
            yazariLabel.Size = new System.Drawing.Size(48, 16);
            yazariLabel.TabIndex = 12;
            yazariLabel.Text = "Yazari:";
            // 
            // yayıneviLabel
            // 
            yayıneviLabel.AutoSize = true;
            yayıneviLabel.Location = new System.Drawing.Point(809, 43);
            yayıneviLabel.Name = "yayıneviLabel";
            yayıneviLabel.Size = new System.Drawing.Size(62, 16);
            yayıneviLabel.TabIndex = 14;
            yayıneviLabel.Text = "Yayınevi:";
            // 
            // sayfaSayisiLabel
            // 
            sayfaSayisiLabel.AutoSize = true;
            sayfaSayisiLabel.Location = new System.Drawing.Point(809, 71);
            sayfaSayisiLabel.Name = "sayfaSayisiLabel";
            sayfaSayisiLabel.Size = new System.Drawing.Size(85, 16);
            sayfaSayisiLabel.TabIndex = 16;
            sayfaSayisiLabel.Text = "Sayfa Sayisi:";
            // 
            // rafNoLabel
            // 
            rafNoLabel.AutoSize = true;
            rafNoLabel.Location = new System.Drawing.Point(819, 99);
            rafNoLabel.Name = "rafNoLabel";
            rafNoLabel.Size = new System.Drawing.Size(52, 16);
            rafNoLabel.TabIndex = 18;
            rafNoLabel.Text = "Raf No:";
            // 
            // açiklamaLabel
            // 
            açiklamaLabel.AutoSize = true;
            açiklamaLabel.Location = new System.Drawing.Point(809, 127);
            açiklamaLabel.Name = "açiklamaLabel";
            açiklamaLabel.Size = new System.Drawing.Size(66, 16);
            açiklamaLabel.TabIndex = 20;
            açiklamaLabel.Text = "Açiklama:";
            // 
            // kayitTarihiLabel
            // 
            kayitTarihiLabel.AutoSize = true;
            kayitTarihiLabel.Location = new System.Drawing.Point(419, 220);
            kayitTarihiLabel.Name = "kayitTarihiLabel";
            kayitTarihiLabel.Size = new System.Drawing.Size(76, 16);
            kayitTarihiLabel.TabIndex = 22;
            kayitTarihiLabel.Text = "Kayit Tarihi:";
            // 
            // proje_DBDataSet
            // 
            this.proje_DBDataSet.DataSetName = "Proje_DBDataSet";
            this.proje_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view_KitapBindingSource
            // 
            this.view_KitapBindingSource.DataMember = "View_Kitap";
            this.view_KitapBindingSource.DataSource = this.proje_DBDataSet;
            // 
            // view_KitapTableAdapter
            // 
            this.view_KitapTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TBLEmanetKitaplarTableAdapter = null;
            this.tableAdapterManager.TBLİadeKitaplarTableAdapter = null;
            this.tableAdapterManager.TBLKitaplarTableAdapter = this.tBLKitaplarTableAdapter;
            this.tableAdapterManager.TBLKitapTürüTableAdapter = this.tBLKitapTürüTableAdapter;
            this.tableAdapterManager.TBLSepetTableAdapter = null;
            this.tableAdapterManager.TBLUyelerTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = KütüphaneProje.Proje_DBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tBLKitaplarTableAdapter
            // 
            this.tBLKitaplarTableAdapter.ClearBeforeFill = true;
            // 
            // tBLKitapTürüTableAdapter
            // 
            this.tBLKitapTürüTableAdapter.ClearBeforeFill = true;
            // 
            // view_KitapBindingNavigator
            // 
            this.view_KitapBindingNavigator.AddNewItem = null;
            this.view_KitapBindingNavigator.BindingSource = this.view_KitapBindingSource;
            this.view_KitapBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.view_KitapBindingNavigator.DeleteItem = null;
            this.view_KitapBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.view_KitapBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.btnGüncelle,
            this.btnSil,
            this.toolStripLabel1,
            this.toolStripTextBox1});
            this.view_KitapBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.view_KitapBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.view_KitapBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.view_KitapBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.view_KitapBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.view_KitapBindingNavigator.Name = "view_KitapBindingNavigator";
            this.view_KitapBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.view_KitapBindingNavigator.Size = new System.Drawing.Size(1238, 27);
            this.view_KitapBindingNavigator.TabIndex = 0;
            this.view_KitapBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 24);
            this.bindingNavigatorCountItem.Text = "/ {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Toplam öğe sayısı";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Başa taşı";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Öne taşı";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Konum";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Geçerli konum";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Arkaya taşı";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Sona taşı";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // btnGüncelle
            // 
            this.btnGüncelle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnGüncelle.Image = ((System.Drawing.Image)(resources.GetObject("btnGüncelle.Image")));
            this.btnGüncelle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGüncelle.Name = "btnGüncelle";
            this.btnGüncelle.Size = new System.Drawing.Size(29, 24);
            this.btnGüncelle.Text = "toolStripButton2";
            this.btnGüncelle.Click += new System.EventHandler(this.btnGüncelle_Click);
            // 
            // btnSil
            // 
            this.btnSil.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSil.Image = ((System.Drawing.Image)(resources.GetObject("btnSil.Image")));
            this.btnSil.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(29, 24);
            this.btnSil.Text = "toolStripButton1";
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(71, 24);
            this.toolStripLabel1.Text = "Kitap Ara";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.BackColor = System.Drawing.Color.DarkKhaki;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(200, 27);
            this.toolStripTextBox1.TextChanged += new System.EventHandler(this.toolStripTextBox1_TextChanged);
            // 
            // view_KitapDataGridView
            // 
            this.view_KitapDataGridView.AutoGenerateColumns = false;
            this.view_KitapDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.view_KitapDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.view_KitapDataGridView.DataSource = this.view_KitapBindingSource;
            this.view_KitapDataGridView.Location = new System.Drawing.Point(0, 374);
            this.view_KitapDataGridView.Name = "view_KitapDataGridView";
            this.view_KitapDataGridView.RowHeadersWidth = 51;
            this.view_KitapDataGridView.RowTemplate.Height = 24;
            this.view_KitapDataGridView.Size = new System.Drawing.Size(1218, 309);
            this.view_KitapDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "KitapID";
            this.dataGridViewTextBoxColumn1.HeaderText = "KitapID";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "KitapTürAdi";
            this.dataGridViewTextBoxColumn2.HeaderText = "KitapTürAdi";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "StokSayisi";
            this.dataGridViewTextBoxColumn3.HeaderText = "StokSayisi";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "BarkodNo";
            this.dataGridViewTextBoxColumn4.HeaderText = "BarkodNo";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "KitapAdi";
            this.dataGridViewTextBoxColumn5.HeaderText = "KitapAdi";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Yazari";
            this.dataGridViewTextBoxColumn6.HeaderText = "Yazari";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Yayınevi";
            this.dataGridViewTextBoxColumn7.HeaderText = "Yayınevi";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "SayfaSayisi";
            this.dataGridViewTextBoxColumn8.HeaderText = "SayfaSayisi";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 125;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "RafNo";
            this.dataGridViewTextBoxColumn9.HeaderText = "RafNo";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 125;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Açiklama";
            this.dataGridViewTextBoxColumn10.HeaderText = "Açiklama";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 125;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "KayitTarihi";
            this.dataGridViewTextBoxColumn11.HeaderText = "KayitTarihi";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 125;
            // 
            // kitapIDTextBox
            // 
            this.kitapIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "KitapID", true));
            this.kitapIDTextBox.Location = new System.Drawing.Point(121, 46);
            this.kitapIDTextBox.Name = "kitapIDTextBox";
            this.kitapIDTextBox.Size = new System.Drawing.Size(200, 22);
            this.kitapIDTextBox.TabIndex = 3;
            // 
            // kitapTürAdiComboBox
            // 
            this.kitapTürAdiComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "KitapTürAdi", true));
            this.kitapTürAdiComboBox.DataSource = this.tBLKitapTürüBindingSource;
            this.kitapTürAdiComboBox.DisplayMember = "KitapTürAdi";
            this.kitapTürAdiComboBox.FormattingEnabled = true;
            this.kitapTürAdiComboBox.Location = new System.Drawing.Point(121, 74);
            this.kitapTürAdiComboBox.Name = "kitapTürAdiComboBox";
            this.kitapTürAdiComboBox.Size = new System.Drawing.Size(200, 24);
            this.kitapTürAdiComboBox.TabIndex = 5;
            this.kitapTürAdiComboBox.ValueMember = "KitapTürüID";
            // 
            // tBLKitapTürüBindingSource
            // 
            this.tBLKitapTürüBindingSource.DataMember = "TBLKitapTürü";
            this.tBLKitapTürüBindingSource.DataSource = this.proje_DBDataSet;
            // 
            // stokSayisiTextBox
            // 
            this.stokSayisiTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "StokSayisi", true));
            this.stokSayisiTextBox.Location = new System.Drawing.Point(121, 104);
            this.stokSayisiTextBox.Name = "stokSayisiTextBox";
            this.stokSayisiTextBox.Size = new System.Drawing.Size(200, 22);
            this.stokSayisiTextBox.TabIndex = 7;
            // 
            // barkodNoTextBox
            // 
            this.barkodNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "BarkodNo", true));
            this.barkodNoTextBox.Location = new System.Drawing.Point(517, 43);
            this.barkodNoTextBox.Name = "barkodNoTextBox";
            this.barkodNoTextBox.Size = new System.Drawing.Size(200, 22);
            this.barkodNoTextBox.TabIndex = 9;
            // 
            // kitapAdiTextBox
            // 
            this.kitapAdiTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "KitapAdi", true));
            this.kitapAdiTextBox.Location = new System.Drawing.Point(517, 71);
            this.kitapAdiTextBox.Name = "kitapAdiTextBox";
            this.kitapAdiTextBox.Size = new System.Drawing.Size(200, 22);
            this.kitapAdiTextBox.TabIndex = 11;
            // 
            // yazariTextBox
            // 
            this.yazariTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "Yazari", true));
            this.yazariTextBox.Location = new System.Drawing.Point(517, 99);
            this.yazariTextBox.Name = "yazariTextBox";
            this.yazariTextBox.Size = new System.Drawing.Size(200, 22);
            this.yazariTextBox.TabIndex = 13;
            // 
            // yayıneviTextBox
            // 
            this.yayıneviTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "Yayınevi", true));
            this.yayıneviTextBox.Location = new System.Drawing.Point(901, 40);
            this.yayıneviTextBox.Name = "yayıneviTextBox";
            this.yayıneviTextBox.Size = new System.Drawing.Size(200, 22);
            this.yayıneviTextBox.TabIndex = 15;
            // 
            // sayfaSayisiTextBox
            // 
            this.sayfaSayisiTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "SayfaSayisi", true));
            this.sayfaSayisiTextBox.Location = new System.Drawing.Point(901, 68);
            this.sayfaSayisiTextBox.Name = "sayfaSayisiTextBox";
            this.sayfaSayisiTextBox.Size = new System.Drawing.Size(200, 22);
            this.sayfaSayisiTextBox.TabIndex = 17;
            // 
            // rafNoTextBox
            // 
            this.rafNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "RafNo", true));
            this.rafNoTextBox.Location = new System.Drawing.Point(901, 96);
            this.rafNoTextBox.Name = "rafNoTextBox";
            this.rafNoTextBox.Size = new System.Drawing.Size(200, 22);
            this.rafNoTextBox.TabIndex = 19;
            // 
            // açiklamaTextBox
            // 
            this.açiklamaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.view_KitapBindingSource, "Açiklama", true));
            this.açiklamaTextBox.Location = new System.Drawing.Point(901, 124);
            this.açiklamaTextBox.Multiline = true;
            this.açiklamaTextBox.Name = "açiklamaTextBox";
            this.açiklamaTextBox.Size = new System.Drawing.Size(200, 64);
            this.açiklamaTextBox.TabIndex = 21;
            // 
            // kayitTarihiDateTimePicker
            // 
            this.kayitTarihiDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.view_KitapBindingSource, "KayitTarihi", true));
            this.kayitTarihiDateTimePicker.Location = new System.Drawing.Point(517, 215);
            this.kayitTarihiDateTimePicker.Name = "kayitTarihiDateTimePicker";
            this.kayitTarihiDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.kayitTarihiDateTimePicker.TabIndex = 23;
            // 
            // TBLKitaplarBindingSource
            // 
            this.TBLKitaplarBindingSource.DataMember = "TBLKitaplar";
            this.TBLKitaplarBindingSource.DataSource = this.proje_DBDataSet;
            // 
            // frmKitapListele
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1238, 750);
            this.Controls.Add(kitapIDLabel);
            this.Controls.Add(this.kitapIDTextBox);
            this.Controls.Add(kitapTürAdiLabel);
            this.Controls.Add(this.kitapTürAdiComboBox);
            this.Controls.Add(stokSayisiLabel);
            this.Controls.Add(this.stokSayisiTextBox);
            this.Controls.Add(barkodNoLabel);
            this.Controls.Add(this.barkodNoTextBox);
            this.Controls.Add(kitapAdiLabel);
            this.Controls.Add(this.kitapAdiTextBox);
            this.Controls.Add(yazariLabel);
            this.Controls.Add(this.yazariTextBox);
            this.Controls.Add(yayıneviLabel);
            this.Controls.Add(this.yayıneviTextBox);
            this.Controls.Add(sayfaSayisiLabel);
            this.Controls.Add(this.sayfaSayisiTextBox);
            this.Controls.Add(rafNoLabel);
            this.Controls.Add(this.rafNoTextBox);
            this.Controls.Add(açiklamaLabel);
            this.Controls.Add(this.açiklamaTextBox);
            this.Controls.Add(kayitTarihiLabel);
            this.Controls.Add(this.kayitTarihiDateTimePicker);
            this.Controls.Add(this.view_KitapDataGridView);
            this.Controls.Add(this.view_KitapBindingNavigator);
            this.Name = "frmKitapListele";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmKitapListele";
            this.Load += new System.EventHandler(this.frmKitapListele_Load);
            ((System.ComponentModel.ISupportInitialize)(this.proje_DBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_KitapBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_KitapBindingNavigator)).EndInit();
            this.view_KitapBindingNavigator.ResumeLayout(false);
            this.view_KitapBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.view_KitapDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLKitapTürüBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TBLKitaplarBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Proje_DBDataSet proje_DBDataSet;
        private System.Windows.Forms.BindingSource view_KitapBindingSource;
        private Proje_DBDataSetTableAdapters.View_KitapTableAdapter view_KitapTableAdapter;
        private Proje_DBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator view_KitapBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.DataGridView view_KitapDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.TextBox kitapIDTextBox;
        private System.Windows.Forms.ComboBox kitapTürAdiComboBox;
        private System.Windows.Forms.TextBox stokSayisiTextBox;
        private System.Windows.Forms.TextBox barkodNoTextBox;
        private System.Windows.Forms.TextBox kitapAdiTextBox;
        private System.Windows.Forms.TextBox yazariTextBox;
        private System.Windows.Forms.TextBox yayıneviTextBox;
        private System.Windows.Forms.TextBox sayfaSayisiTextBox;
        private System.Windows.Forms.TextBox rafNoTextBox;
        private System.Windows.Forms.TextBox açiklamaTextBox;
        private System.Windows.Forms.DateTimePicker kayitTarihiDateTimePicker;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton btnGüncelle;
        private System.Windows.Forms.ToolStripButton btnSil;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private Proje_DBDataSetTableAdapters.TBLKitapTürüTableAdapter tBLKitapTürüTableAdapter;
        private System.Windows.Forms.BindingSource tBLKitapTürüBindingSource;
        private System.Windows.Forms.BindingSource TBLKitaplarBindingSource;
        private Proje_DBDataSetTableAdapters.TBLKitaplarTableAdapter tBLKitaplarTableAdapter;
    }
}