﻿namespace KütüphaneProje
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnÇıkış = new System.Windows.Forms.Button();
            this.btnİadeKitaplar = new System.Windows.Forms.Button();
            this.btnEmanetKitap = new System.Windows.Forms.Button();
            this.btnKitapListele = new System.Windows.Forms.Button();
            this.btnKitapEkle = new System.Windows.Forms.Button();
            this.btnKitapTürleri = new System.Windows.Forms.Button();
            this.btnÜyeListele = new System.Windows.Forms.Button();
            this.btnÜyeEkle = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnÇıkış);
            this.panel1.Controls.Add(this.btnİadeKitaplar);
            this.panel1.Controls.Add(this.btnEmanetKitap);
            this.panel1.Controls.Add(this.btnKitapListele);
            this.panel1.Controls.Add(this.btnKitapEkle);
            this.panel1.Controls.Add(this.btnKitapTürleri);
            this.panel1.Controls.Add(this.btnÜyeListele);
            this.panel1.Controls.Add(this.btnÜyeEkle);
            this.panel1.Location = new System.Drawing.Point(2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(216, 755);
            this.panel1.TabIndex = 0;
            // 
            // btnÇıkış
            // 
            this.btnÇıkış.BackColor = System.Drawing.Color.Red;
            this.btnÇıkış.Location = new System.Drawing.Point(10, 658);
            this.btnÇıkış.Name = "btnÇıkış";
            this.btnÇıkış.Size = new System.Drawing.Size(203, 88);
            this.btnÇıkış.TabIndex = 7;
            this.btnÇıkış.Text = "Çıkış";
            this.btnÇıkış.UseVisualStyleBackColor = false;
            this.btnÇıkış.Click += new System.EventHandler(this.btnÇıkış_Click);
            // 
            // btnİadeKitaplar
            // 
            this.btnİadeKitaplar.Image = ((System.Drawing.Image)(resources.GetObject("btnİadeKitaplar.Image")));
            this.btnİadeKitaplar.Location = new System.Drawing.Point(10, 564);
            this.btnİadeKitaplar.Name = "btnİadeKitaplar";
            this.btnİadeKitaplar.Size = new System.Drawing.Size(203, 88);
            this.btnİadeKitaplar.TabIndex = 6;
            this.btnİadeKitaplar.Text = "İade Kitaplar";
            this.btnİadeKitaplar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnİadeKitaplar.UseVisualStyleBackColor = true;
            // 
            // btnEmanetKitap
            // 
            this.btnEmanetKitap.Image = ((System.Drawing.Image)(resources.GetObject("btnEmanetKitap.Image")));
            this.btnEmanetKitap.Location = new System.Drawing.Point(10, 476);
            this.btnEmanetKitap.Name = "btnEmanetKitap";
            this.btnEmanetKitap.Size = new System.Drawing.Size(203, 82);
            this.btnEmanetKitap.TabIndex = 5;
            this.btnEmanetKitap.Text = "Emanet Kitaplar";
            this.btnEmanetKitap.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEmanetKitap.UseVisualStyleBackColor = true;
            // 
            // btnKitapListele
            // 
            this.btnKitapListele.Image = ((System.Drawing.Image)(resources.GetObject("btnKitapListele.Image")));
            this.btnKitapListele.Location = new System.Drawing.Point(10, 388);
            this.btnKitapListele.Name = "btnKitapListele";
            this.btnKitapListele.Size = new System.Drawing.Size(203, 82);
            this.btnKitapListele.TabIndex = 4;
            this.btnKitapListele.Text = "Kitap Listele";
            this.btnKitapListele.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKitapListele.UseVisualStyleBackColor = true;
            this.btnKitapListele.Click += new System.EventHandler(this.btnKitapListele_Click);
            // 
            // btnKitapEkle
            // 
            this.btnKitapEkle.Image = ((System.Drawing.Image)(resources.GetObject("btnKitapEkle.Image")));
            this.btnKitapEkle.Location = new System.Drawing.Point(10, 291);
            this.btnKitapEkle.Name = "btnKitapEkle";
            this.btnKitapEkle.Size = new System.Drawing.Size(203, 91);
            this.btnKitapEkle.TabIndex = 3;
            this.btnKitapEkle.Text = "Kitap Ekle";
            this.btnKitapEkle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKitapEkle.UseVisualStyleBackColor = true;
            this.btnKitapEkle.Click += new System.EventHandler(this.btnKitapEkle_Click);
            // 
            // btnKitapTürleri
            // 
            this.btnKitapTürleri.Image = ((System.Drawing.Image)(resources.GetObject("btnKitapTürleri.Image")));
            this.btnKitapTürleri.Location = new System.Drawing.Point(10, 201);
            this.btnKitapTürleri.Name = "btnKitapTürleri";
            this.btnKitapTürleri.Size = new System.Drawing.Size(203, 84);
            this.btnKitapTürleri.TabIndex = 2;
            this.btnKitapTürleri.Text = "Kitap Türleri";
            this.btnKitapTürleri.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKitapTürleri.UseVisualStyleBackColor = true;
            this.btnKitapTürleri.Click += new System.EventHandler(this.btnKitapTürleri_Click);
            // 
            // btnÜyeListele
            // 
            this.btnÜyeListele.Image = ((System.Drawing.Image)(resources.GetObject("btnÜyeListele.Image")));
            this.btnÜyeListele.Location = new System.Drawing.Point(10, 104);
            this.btnÜyeListele.Name = "btnÜyeListele";
            this.btnÜyeListele.Size = new System.Drawing.Size(203, 91);
            this.btnÜyeListele.TabIndex = 1;
            this.btnÜyeListele.Text = "Üye Listele";
            this.btnÜyeListele.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnÜyeListele.UseVisualStyleBackColor = true;
            this.btnÜyeListele.Click += new System.EventHandler(this.btnÜyeListele_Click);
            // 
            // btnÜyeEkle
            // 
            this.btnÜyeEkle.Image = ((System.Drawing.Image)(resources.GetObject("btnÜyeEkle.Image")));
            this.btnÜyeEkle.Location = new System.Drawing.Point(10, 11);
            this.btnÜyeEkle.Name = "btnÜyeEkle";
            this.btnÜyeEkle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnÜyeEkle.Size = new System.Drawing.Size(203, 87);
            this.btnÜyeEkle.TabIndex = 0;
            this.btnÜyeEkle.Text = "Üye Ekle";
            this.btnÜyeEkle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnÜyeEkle.UseVisualStyleBackColor = true;
            this.btnÜyeEkle.Click += new System.EventHandler(this.btnÜyeEkle_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(224, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(750, 746);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(986, 752);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnİadeKitaplar;
        private System.Windows.Forms.Button btnEmanetKitap;
        private System.Windows.Forms.Button btnKitapListele;
        private System.Windows.Forms.Button btnKitapEkle;
        private System.Windows.Forms.Button btnKitapTürleri;
        private System.Windows.Forms.Button btnÜyeListele;
        private System.Windows.Forms.Button btnÜyeEkle;
        private System.Windows.Forms.Button btnÇıkış;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

