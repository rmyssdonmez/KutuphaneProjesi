﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KütüphaneProje
{
    public partial class frmUyeListele : Form
    {
        public frmUyeListele()
        {
            InitializeComponent();
        }

        private void frmUyeListele_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'proje_DBDataSet.TBLUyeler' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.tBLUyelerTableAdapter.Fill(this.proje_DBDataSet.TBLUyeler);
            lblKayitSayisi.Text = "Toplam " + db.KitapSayisi() + " listelendi";
            lblOkunanKitapSayisi.Text = "Okunan Kitap Sayısı Toplamı = " + db.ToplamKitapSayisi();
            pictureBox1.ImageLocation = dataGridView1.Rows[0].Cells["Resim"].Value.ToString();



        }

        private void btnResimSec_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = openFileDialog1.FileName;
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = db.AdiSoyadiAra2("%" + txtAdSoyadAra.Text + "%");
        }

        private void btnİptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }
     

        Proje_DBDataSetTableAdapters.TBLUyelerTableAdapter db = new Proje_DBDataSetTableAdapters.TBLUyelerTableAdapter();
        private void btnGüncelle_Click(object sender, EventArgs e)
        {
            db.UyeGüncelle(
            txtAdSoyad.Text,
            txtTelefon.Text,
            txtAdres.Text,
            txtMail.Text,
            pictureBox1.ImageLocation,
            Convert.ToInt32(txtKitapSayısı.Text),
            dateTimePicker1.Value.ToString("yyyy-MM-dd"),

           Convert.ToInt32(txtUyeID.Text)

   );

            MessageBox.Show("Üye Güncelleme İşlemi Başarılı", "Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Information);

            Temizle();
            
        }

        private void Temizle()
        {
            foreach (Control item in Controls)
            {
                if (item is TextBox txt)
                {
                    txt.Text = "";
                }
            }

            pictureBox1.ImageLocation = "";
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            db.UyeSil(


         Convert.ToInt32(txtUyeID.Text)

 );

            MessageBox.Show("Üye Silme İşlemi Başarılı", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            Temizle();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pictureBox1.ImageLocation = dataGridView1.CurrentRow.Cells["Resim"].Value.ToString();

        }

        private void txtAdresAra_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = db.AdresAra2("%" + txtAdresAra.Text + "%");
        }
    }
       
     
    }

