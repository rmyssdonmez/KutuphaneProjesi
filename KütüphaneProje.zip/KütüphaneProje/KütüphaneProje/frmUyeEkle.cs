﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace KütüphaneProje
{
    public partial class frmUyeEkle : Form
    {
        public frmUyeEkle()
        {
            InitializeComponent();
        }

        private void btnResimSec_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = openFileDialog1.FileName;
            }
        }
        Proje_DBDataSetTableAdapters.TBLUyelerTableAdapter db = new Proje_DBDataSetTableAdapters.TBLUyelerTableAdapter();


        private void btnKaydet_Click(object sender, EventArgs e)
        {
         db.UyeEkle(
         txtAdSoyad.Text,
         txtTelefon.Text,
         txtAdres.Text,
         txtMail.Text,
         pictureBox1.ImageLocation,
         Convert.ToInt32(txtKitapSayısı.Text),
        dateTimePicker1.Value.ToString("yyyy-MM-dd")
);

            MessageBox.Show("Üye Ekleme İşlemi Başarılı", "Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Information);
            foreach (Control item in Controls)
            {
                TextBox txt = item as TextBox;
                if (txt != null)
                {
                    txt.Text = "";
                }
            }
            pictureBox1.ImageLocation = "";

        }


        private void frmUyeEkle_Load(object sender, EventArgs e)
        {

        }

        private void btnİptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
