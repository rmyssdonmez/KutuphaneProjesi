﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KütüphaneProje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnÜyeEkle_Click(object sender, EventArgs e)
        {
           Form UyeEkle = new frmUyeEkle();
            UyeEkle.Show();
        }

        private void btnÜyeListele_Click(object sender, EventArgs e)
        {
            Form UyeListele = new frmUyeListele();
            UyeListele.Show();
        }

        private void btnÇıkış_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnKitapTürleri_Click(object sender, EventArgs e)
        {
            Form KitapTur = new KitapTur();
            KitapTur.Show();
        }

        private void btnKitapEkle_Click(object sender, EventArgs e)
        {
            Form KitapEkle= new frmKitapEkle();
            KitapEkle.Show();
        }

        private void btnKitapListele_Click(object sender, EventArgs e)
        {
            Form KitapListele = new frmKitapListele();
            KitapListele.Show();
        }
    }
}
